import React from "react";
import {
  View,
  Text,
  StyleSheet,
  ActivityIndicator,
  ScrollView,
  FlatList
} from "react-native";

export default class StationList extends React.Component {
  static navigationOptions = {
    title: "Danh Sách Trạm"
  };

  constructor(props) {
    super(props);
    this.state = {
      isLoading: true,
      dataSource: []
    };
  }

  componentDidMount() {
    url = `http://192.168.100.88:8000/api/station_information/stations/?format=json`;
    return fetch(url)
      .then(response => response.json())
      .then(responseJson => {
        this.setState({
          isLoading: false,
          dataSource: responseJson.results
        });
      })
      .catch(error => {
        console.log("ERROR!!!!");
        console.log(error);
      });
  }
  render() {
    if (this.state.isLoading) {
      return (
        <View style={styles.container}>
          <Text>Loading the Station Data</Text>
          <ActivityIndicator />
        </View>
      );
    } else {
      console.log("ELSE CASE");
      console.log(this.state.dataSource);
      return (
        <Text style={styles.container}>Something is missing
            <FlatList
                data={this.state.dataSource}
                renderItem={({item}) => <Text>{item.station_name}</Text>}
                keyExtractor={({id}, index) => id}
            />
        </Text>
      );
      //   let station_names = this.state.dataSource.map(val => {
      //     return (
      //       <View style={styles.item}>
      //         {/* <Text>{val.station_name}</Text> */}
      //         <Text>Something is missing!</Text>
      //       </View>
      //     );
      //   });

      return (
        <View style={styles.container}>
          <View
            style={styles.container}
            contentContainerStyle={styles.contentContainer}
          >
            {station_names}
          </View>
        </View>
      );
    }
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center"
    // justifyContent: "center"
  },

  item: {
    flex: 1,
    alignSelf: "stretch",
    margin: 10,
    alignItems: "center",
    borderBottomWidth: 1,
    borderBottomColor: "#eee"
  }
});

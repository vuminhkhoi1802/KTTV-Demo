import React from "react";
import {
  View,
  Text,
  StyleSheet,
  ActivityIndicator,
  ScrollView,
  FlatList
} from "react-native";

export default class ControlGroup extends React.Component {
  render() {
    return <Text>Ban Chỉ Huy</Text>;
  }
}

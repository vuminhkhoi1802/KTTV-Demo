import React from "react";
import {
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  ActivityIndicator,
  Button
} from "react-native";

export default class HomeScreen extends React.Component {
  static navigationOptions = {
    title: "Kiểu Trạm"
  };

  constructor(props) {
    super(props);
    this.state = {
      isLoading: true,
      dataSource: []
    };
  }

  componentDidMount() {
    return fetch(
      "http://192.168.100.88:8000/api/station_information/stationtype/?format=json"
    )
      .then(response => response.json())
      .then(responseJson => {
        this.setState({
          isLoading: false,
          dataSource: responseJson.results
        });
      })
      .catch(error => {
        console.log(error);
      });
  }
  // async componentDidMount() {
  //   try {
  //     //Assign the promise unresolved first then get the data using the json method.
  //     console.log("Something")
  //     const res = await fetch(
  //       "http://192.168.100.88:8000/api/station_information/stationtype/?format=json"
  //     );
  //     this.state.test = res;
  //     console.log()
  //     const responseJson = await res.json();

  //     console.log("Something0");
  //     // this.setState({pokeList: pokemon.results, loading: false});
  //   } catch (err) {
  //     console.log("Error fetching data-----------", err);
  //   }
  // }
  render() {
    if (this.state.isLoading) {
      return (
        <View style={styles.container}>
          <Text>Loading the Station Type Data</Text>
          <ActivityIndicator />
        </View>
      );
    } else {
      let station_types = this.state.dataSource.map(val => {
        return (
          <View style={styles.container}>
            <Button
              title={val.stationtype_name}
              onPress={() => {
                this.props.navigation.navigate("StationList");
              }}
            />
          </View>
        );
      });
      return (
        <View style={styles.container}>
          <ScrollView
            style={styles.container}
            contentContainerStyle={styles.contentContainer}
          >
            {station_types}
          </ScrollView>
        </View>
      );
    }

    //   let station_types = this.state.dataSource.map((val) => {
    //     return (

    //       <View style={styles.item}>
    //         <Button
    //           title={val.stationtype_name}
    //           onPress={() => {
    //             this.props.navigation.navigate("StationList");
    //           }}
    //         />
    //       </View>
    //     );
    //   });
  }
}

// _maybeRenderDevelopmentModeWarning() {
//   if (__DEV__) {
//     const learnMoreButton = (
//       <Text onPress={this._handleLearnMorePress} style={styles.helpLinkText}>
//         Learn more
//       </Text>
//     );

//     return (
//       <Text style={styles.developmentModeText}>
//         Development mode is enabled, your app will be slower but you can use useful development
//         tools. {learnMoreButton}
//       </Text>
//     );
//   } else {
//     return (
//       <Text style={styles.developmentModeText}>
//         You are not in development mode, your app will run at full speed.
//       </Text>
//     );
//   }
// }
// }

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff"
    // alignItems: "center",
    // justifyContent: "center"
  },
  item: {
    flex: 1,
    alignSelf: "stretch",
    margin: 10,
    alignItems: "center",
    justifyContent: "center",
    borderBottomWidth: 1,
    borderBottomColor: "#eee"
  }
});

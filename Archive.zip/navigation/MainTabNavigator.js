import React from 'react';
import { Platform } from 'react-native';
import { createStackNavigator, createBottomTabNavigator } from 'react-navigation';

import TabBarIcon from '../components/TabBarIcon';
import HomeScreen from '../screens/HomeScreen';
import LinksScreen from '../screens/LinksScreen';
import SettingsScreen from '../screens/SettingsScreen';
import StationList from '../screens/TramQuanTrac/StationList';
import ControlGroup from '../screens/BanChiHuy/ControlGroup';


const HomeStack = createStackNavigator({
  Home: HomeScreen,
  StationList: StationList
});

HomeStack.navigationOptions = {
  tabBarLabel: 'Quản Trị',
  tabBarIcon: ({ focused }) => (
    <TabBarIcon
      focused={focused}
      
        name={Platform.OS === 'ios' ? 'ios-options' : 'md-options'}
      
    />
  ),
};

const LinksStack = createStackNavigator({
  Links: LinksScreen,
});

LinksStack.navigationOptions = {
  tabBarLabel: 'Quan Trắc',
  tabBarIcon: ({ focused }) => (
    <TabBarIcon
      focused={focused}
      name={Platform.OS === 'ios' ? 'ios-options' : 'md-options'}
    />
  ),
};

const ControlStack = createStackNavigator({
  Links: ControlGroup,
});

ControlStack.navigationOptions = {
  tabBarLabel: 'Ban Chỉ Huy',
  tabBarIcon: ({ focused }) => (
    <TabBarIcon
      focused={focused}
      name={Platform.OS === 'ios' ? 'ios-options' : 'md-options'}
    />
  ),
}

const SettingsStack = createStackNavigator({
  Settings: SettingsScreen,
});

SettingsStack.navigationOptions = {
  tabBarLabel: 'Báo Cáo',
  tabBarIcon: ({ focused }) => (
    <TabBarIcon
      focused={focused}
      name={Platform.OS === 'ios' ? 'ios-options' : 'md-options'}
    />
  ),
};

export default createBottomTabNavigator({
  HomeStack,
  LinksStack,
  SettingsStack,
  ControlStack
});
